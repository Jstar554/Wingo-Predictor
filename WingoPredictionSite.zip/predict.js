async function predict() {
    const res = await fetch('data.json');
    const history = await res.json();

    const last = history[history.length - 1];
    const number = (last.number * 3 + 1) % 10;
    const size = number >= 5 ? "Big" : "Small";

    document.getElementById("result").innerHTML =
        `Prediction:<br>Number: ${number}<br>Size: ${size}`;
}