Wingo 30s Prediction Website

1. Upload all these files to your GitHub repository.
2. Make sure index.html is in the root folder.
3. Go to GitHub -> Settings -> Pages -> Source: main branch / root
4. Your live site will be at: https://<your-username>.github.io/<repo-name>/

You can modify prediction logic in predict.js